package com.pruebas.vinicio.prueba1;

import org.junit.Test;

import java.io.Console;

import static org.junit.Assert.*;

public class MainActivityTest {

    @Test
    public void login() throws  Exception{
        String id = "30514102";
        String pin = "1111";

        String idIngresado = "30514102";
        String pinIngreasado = "7777";

        assertEquals(id, idIngresado);
        assertEquals(pin, pinIngreasado);
    }
}