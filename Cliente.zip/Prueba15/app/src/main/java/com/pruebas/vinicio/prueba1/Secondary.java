package com.pruebas.vinicio.prueba1;



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

public class Secondary extends AppCompatActivity {
    Button bttareas, btrecursos;
    private BottomNavigationView mMainNav;
    private FrameLayout mMainFrame;


    private MenuFragment menuFragment;
    private OrdenFragment ordenFragment;
    private EstadisticasFragment estadisticasFragment;
    private AmigosFragment amigosFragment;
    private PerfilFragment perfilFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        mMainFrame = (FrameLayout) findViewById(R.id.main_frame);
        mMainNav = (BottomNavigationView) findViewById(R.id.main_nav);


        menuFragment = new MenuFragment();
        ordenFragment = new OrdenFragment();
        estadisticasFragment = new EstadisticasFragment();
        amigosFragment = new AmigosFragment();
        perfilFragment = new PerfilFragment();


        setFragment(menuFragment);


        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_menu:
                        mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(menuFragment);
                        return true;
                    case R.id.nav_ordenes:
                        mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(ordenFragment);
                        return true;
                    case R.id.nav_estadisticas:
                        mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(estadisticasFragment);
                        return true;
                    case R.id.nav_amigos:
                        mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(amigosFragment);
                        return true;
                    case R.id.nav_perfil:
                        mMainNav.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(perfilFragment);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame, fragment);
        fragmentTransaction.commit();
    }
}

